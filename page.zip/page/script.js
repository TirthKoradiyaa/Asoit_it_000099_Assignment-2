$(document).ready(function() {
    $("#feedbackForm").submit(function(event) {
      event.preventDefault();
      
      var name = $("#name").val();
      var email = $("#email").val();
      var message = $("#message").val();
      
      // Validation logic (You can customize this as per your requirements)
      if (name.trim() === "") {
        $(".error").text("Please enter your name.");
        return;
      }
      
      if (email.trim() === "") {
        $(".error").text("Please enter your email.");
        return;
      }
      
      if (message.trim() === "") {
        $(".error").text("Please enter your message.");
        return;
      }
      
      // Clear previous error messages
      $(".error").text("");
      
      // Simulate form submission (you can replace this with your own logic)
      // Here, we display a success message
      $(".success").text("Thank you for your feedback!");
      
      // Reset form fields
      $("#name").val("");
      $("#email").val("");
      $("#message").val("");
    });
  });